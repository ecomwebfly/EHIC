import { Component, Inject } from '@angular/core';
import { Http } from '@angular/http';
 

@Component({
    selector: 'fetchdata',
    templateUrl: './fetchdata.component.html'
})
export class FetchDataComponent {
    public contacts: Contacts[];

    constructor(http: Http, @Inject('BASE_URL') baseUrl: string) {
        http.get(baseUrl + 'api/ContactsMasters/GetContactsMaster').subscribe(result => {
            this.contacts = result.json() as Contacts[];
        }, error => console.error(error));
    }



}

interface Contacts {
       id: number;
       firstName: string;
       lastName: string;
       email: string;
       phoneNumber: string;
       status: string;
       createdBy: string;
       createdDate : string;
       modifiedBy: string;
       modifiedDate : string;
}
