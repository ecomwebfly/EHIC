import { Component, Inject} from '@angular/core';
import { Http } from '@angular/http';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";


@Component({
    selector: 'addcontacts',
    templateUrl: './addcontacts.component.html'
})
export class addcontactsComponent{
    

    public contacts: Contacts;
    //public http: Http;
    //public @Inject('BASE_URL') baseUrl: string;

    constructor(http: Http, @Inject('BASE_URL') baseUrl: string) {
      
    }



    AddContacts() {
        this.http.post<Contacts>(this.baseUrl + 'api/ContactsMasters/PostContactsMaster', { title: 'Angular POST Request' }).subscribe((data: { id: number; }) => {
            this.contacts.id = data.id;
        })
     
    }

}
interface Contacts {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    phoneNumber: string;
    status: string;
    createdBy: string;
    createdDate: string;
    modifiedBy: string;
    modifiedDate: string;
}