﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EHIC.Models;

namespace EHIC.Controllers
{
    [Produces("application/json")]
    [Route("api/ContactsMasters")]
    public class ContactsMastersController : Controller
    {
        private readonly EHIContext _context;

        public ContactsMastersController(EHIContext context)
        {
            _context = context;
        }

        // GET: api/ContactsMasters
        [HttpGet]
        public IEnumerable<ContactsMaster> GetContactsMaster()
        {
            return _context.ContactsMaster;
        }

        // GET: api/ContactsMasters/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetContactsMaster([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var contactsMaster = await _context.ContactsMaster.SingleOrDefaultAsync(m => m.Id == id);

            if (contactsMaster == null)
            {
                return NotFound();
            }

            return Ok(contactsMaster);
        }

        // PUT: api/ContactsMasters/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutContactsMaster([FromRoute] int id, [FromBody] ContactsMaster contactsMaster)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != contactsMaster.Id)
            {
                return BadRequest();
            }

            _context.Entry(contactsMaster).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ContactsMasterExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/ContactsMasters
        [HttpPost]
        public async Task<IActionResult> PostContactsMaster([FromBody] ContactsMaster contactsMaster)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _context.ContactsMaster.Add(contactsMaster);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetContactsMaster", new { id = contactsMaster.Id }, contactsMaster);
        }

        // DELETE: api/ContactsMasters/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteContactsMaster([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var contactsMaster = await _context.ContactsMaster.SingleOrDefaultAsync(m => m.Id == id);
            if (contactsMaster == null)
            {
                return NotFound();
            }

            _context.ContactsMaster.Remove(contactsMaster);
            await _context.SaveChangesAsync();

            return Ok(contactsMaster);
        }

        private bool ContactsMasterExists(int id)
        {
            return _context.ContactsMaster.Any(e => e.Id == id);
        }
    }
}